export type ProxyHostSecurity = "inbound_default" | "none" | "tls"
