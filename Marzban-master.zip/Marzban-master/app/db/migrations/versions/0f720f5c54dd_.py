"""empty message

Revision ID: 0f720f5c54dd
Revises: 5a4446e7b165, fe7796f840a4
Create Date: 2023-10-27 16:19:33.690427

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0f720f5c54dd'
down_revision = ('5a4446e7b165', 'fe7796f840a4')
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
